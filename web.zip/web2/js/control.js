var sendbtn = $('#send');
var redrawbtn = $('#redraw');
var canvas = $('#paint')[0];
//var menu = $('.menu ul a');

var save = false;
var char = parseInt((new URLSearchParams(window.location.search)).get('char'));
if (!char) char = 0;

const fileExt = ((MediaRecorder.isTypeSupported('video/webm')) ? 'webm' : 'mp4');

const chars = [
    [
        'あ', 'a'
    ],
    [
        'い', 'i'
    ],
    [
        'う', 'u'
    ],
    [
        'え', 'e'
    ],
    [
        'お', 'o'
    ],
    [
        'か', 'ka'
    ],
    [
        'き', 'ki'
    ],
    [
        'く', 'ku'
    ],
    [
        'け', 'ke'
    ],
    [
        'こ', 'ko'
    ],
    [
        'さ', 'sa'
    ],
    [
        'し', 'si'
    ],
    [
        'す', 'su'
    ],
    [
        'せ', 'se'
    ],
    [
        'そ', 'so'
    ],
    [
        'た', 'ta'
    ],
    [
        'ち', 'ti'
    ],
    [
        'つ', 'tu'
    ],
    [
        'て', 'te'
    ],
    [
        'と', 'to'
    ]
];

function saveToDataBase(num, blob) {
    setTimeout(() => {
        console.log(num);
        const fileReader = new FileReader();

        fileReader.readAsArrayBuffer(blob);

        fileReader.onload = async(event) => {
            const fileName = chars[num][1] + '.' + fileExt;
            await fetch('/upload?fileName=' + fileName, {
                'method': 'POST',
                'headers': {
                    'content-type': "application/octet-stream",
                },
                'body': blob
            })
        }
    }, 0);

    if (num == 19) {
        window.location = "/end.html";
    }
}


let recording = false;
let mediaRecorder, recordedChunks;

var showchar = $('#show-char');
showchar.text(chars[char][0])

function clearCanvas() {
    document.getElementById('result').textContent += ctx + '\n';
    ctx.fillRect(0, 0, paint.width, paint.height);
}

function startRecord() {
    if (!recording) {
        try {
            recording = true;
            const stream = canvas.captureStream(15);
            mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'video/' + fileExt,
                ignoreMutedMedia: true
            });
        } catch (e) {
            recording = false;
        }
        recordedChunks = [];
        mediaRecorder.ondataavailable = e => {
            if (e.data.size > 0) {
                recordedChunks.push(e.data);
                if (save) saveCanvas();
            }
        };
        mediaRecorder.start();
    }
}

function saveCanvas() {
    setTimeout(() => {
        const blob = new Blob(recordedChunks, {
            type: "video/" + fileExt
        });
        document.getElementById('result').textContent += "<p>from savecanvas: " + blob.size + "</p>";
        saveToDataBase(char, blob);
    }, 0);
}

function stopRecord() {
    recording = false;
    mediaRecorder.stop();
}

function next() {
    window.location = window.location.origin + '/collect?char=' + (char + 1);
}

function sendBtnClicked() {
    save = true;
    console.log(char);
    stopRecord();
    setTimeout(next, 100);
}

sendbtn.bind('click', sendBtnClicked)

function redrawBtnClicked() {
    save = false;
    stopRecord();
    clearCanvas();
}

redrawbtn.bind('click', redrawBtnClicked)
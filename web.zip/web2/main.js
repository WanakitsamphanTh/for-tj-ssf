const http = require('http'); // import http module
const fs = require("fs");
const path = require('path')
const server = http.createServer(); // create server

const chars = [
    [
        'あ', 'a'
    ],
    [
        'い', 'i'
    ],
    [
        'う', 'u'
    ],
    [
        'え', 'e'
    ],
    [
        'お', 'o'
    ],
    [
        'か', 'ka'
    ],
    [
        'き', 'ki'
    ],
    [
        'く', 'ku'
    ],
    [
        'け', 'ke'
    ],
    [
        'こ', 'ko'
    ],
    [
        'さ', 'sa'
    ],
    [
        'し', 'si'
    ],
    [
        'す', 'su'
    ],
    [
        'せ', 'se'
    ],
    [
        'そ', 'so'
    ],
    [
        'た', 'ta'
    ],
    [
        'ち', 'ti'
    ],
    [
        'つ', 'tu'
    ],
    [
        'て', 'te'
    ],
    [
        'と', 'to'
    ]
];

server.on('request', (req, res) => {
    console.log(req.url);
    if (req.url.startsWith('/upload') && req.method == 'POST') {
        console.log("File uploading");
        const query = new URLSearchParams(req.url);
        const fileName = query.get('/upload?fileName');
        let kana = path.parse(fileName).name;
        let err;
        let num = fs.readdirSync('Datasets/' + kana).length;
        let dir = 'Datasets/' + kana + '/';
        let fname = kana + num + path.parse(fileName).ext;
        let newFile = fs.createWriteStream(dir + fname);
        newFile.end();
        req.on('data', chunk => {
            fs.appendFileSync(dir + fname, chunk);
        });
        console.log("Successfully uploaded");
        req.on('end', () => {
            err = fs.appendFileSync(dir + 'summary.csv', fname + ",\n");
            console.log("Successfully stored: " + fname);
        });
        res.end("Successfully uploaded & stored");
    } else
    if (req.url === '/' && req.method === 'GET') {
        res.end(fs.readFileSync(__dirname + '/index.html'));
    } else if (req.url.startsWith('/collect') && req.method === 'GET') {
        res.end(fs.readFileSync(__dirname + '/index.html'));
    } else if (req.method === 'GET') {
        try {
            res.end(fs.readFileSync(__dirname + req.url));
        } catch (e) {
            res.end();

        }
    }
})

server.listen(8080, () => {
    console.log('Server running on port 8080') // listening on the port
})
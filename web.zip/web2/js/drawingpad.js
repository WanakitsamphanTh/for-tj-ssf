var sketch = document.getElementById('sketch');
var paint = document.getElementById('paint');
var ctx = paint.getContext('2d');
var sketch_style = getComputedStyle(sketch);

paint.width = 250;
paint.height = 250;

var mouse = { x: 0, y: 0 };

ctx.fillStyle = '#ffffff';
ctx.fillRect(0, 0, 250, 250);

paint.addEventListener('mousemove', function(e) {
    mouse.x = e.pageX - this.offsetLeft;
    mouse.y = e.pageY - this.offsetTop;
}, false);

ctx.lineJoin = 'round';
ctx.lineCap = 'round';

ctx.strokeStyle = "black";

if ((('ontouchstart' in window) || (navigator.msMaxTouchPoints > 0))) {
    let draw_touch = function(e) {
        let touch = e.touches[0];
        startRecord();
        ctx.beginPath();
        ctx.moveTo(touch.pageX - touch.target.offsetLeft, touch.pageY - touch.target.offsetTop);
        document.getElementById('result').textContent += mediaRecorder;
        paint.addEventListener('touchmove', onPaintTouch, false);
    }
    var onPaintTouch = function(e) {
        let touch = e.touches[0];
        ctx.lineTo(touch.pageX - touch.target.offsetLeft, touch.pageY - touch.target.offsetTop);
        ctx.stroke();
    }
    paint.addEventListener('touchstart', draw_touch, false);
    paint.addEventListener('touchend', function() {
        paint.removeEventListener('touchmove', onPaintTouch, false);
        $('#result').append('chuncks: ' + recordedChunks + '<br>');
    }, false);
} else {

    let draw = function() {
        startRecord();
        ctx.beginPath();
        ctx.moveTo(mouse.x, mouse.y);

        paint.addEventListener('mousemove', onPaint, false);
    }
    var onPaint = function() {
        ctx.lineTo(mouse.x, mouse.y);
        ctx.stroke();
    };
    paint.addEventListener('mousedown', draw, false);
    paint.addEventListener('mouseup', function() {
        paint.removeEventListener('mousemove', onPaint, false);
        $('#result').append('chuncks: ' + recordedChunks + '<br>');
    }, false);
}


/*
How to record an HTML canvas element and make a GIF:
    https://dev.to/ndesmic/how-to-record-a-canvas-element-and-make-a-gif-4852
*/